﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelScript : MonoBehaviour {
    public List<GameObject> nodes = new List<GameObject>();
    Mesh mesh;
    BoxCollider meshCollider;


    //Stat
    public float strength = 1000.0f;

    private void Start() {
        mesh = GetComponent<MeshFilter>().mesh;
        meshCollider = GetComponent<BoxCollider>();
    }

    private void Update() {
        if (nodes.Count > 0) {
            MatchVertices(nodes);
            CalculateStress();
        }
    }

    void CalculateStress() {
        //Stuff later
    }

    void MatchVertices(List<GameObject> nodePositions) {
        mesh.vertices = new Vector3[] {
            transform.InverseTransformPoint(nodePositions[0].transform.position),
            transform.InverseTransformPoint(nodePositions[1].transform.position),
            transform.InverseTransformPoint(nodePositions[2].transform.position),
            transform.InverseTransformPoint(nodePositions[3].transform.position),
        };


        if (meshCollider) {
            Vector3 oldTransform = gameObject.transform.position;
            Quaternion oldrotation = gameObject.transform.rotation;
            Renderer thisRenderer = transform.GetComponent<Renderer>();
            transform.rotation = Quaternion.identity;
            Bounds bounds = new Bounds(gameObject.transform.position, thisRenderer.bounds.size);
            meshCollider.size = bounds.size;
            gameObject.transform.position = oldTransform;
            gameObject.transform.rotation = oldrotation;
        }

        //mesh.RecalculateNormals();
        //mesh.RecalculateBounds();
        //mesh.Optimize();
    }

    public void AssignNodes(List<GameObject> assignedNodes) {
        for (int i = 0; i < assignedNodes.Count; i++) {
            nodes.Insert(i, assignedNodes[i]);
            CreateLink(assignedNodes[i], assignedNodes[i].transform.position);
        }
    }

    ConfigurableJoint CreateLink(GameObject attachedBody, Vector3 connectionPoint) {
        //This creates the configurable joint between platfroms that have near edges.
        ConfigurableJoint link1 = gameObject.AddComponent<ConfigurableJoint>();
        SoftJointLimitSpring springJoint = new SoftJointLimitSpring();
        springJoint.spring = 100.0f;
        springJoint.damper = 1000.0f;

        SoftJointLimit springJointLimit = new SoftJointLimit();
        springJointLimit.limit = 100.0f;

        JointDrive springJointDrive = new JointDrive();
        springJointDrive.positionSpring = strength;
        springJointDrive.maximumForce = 99999.9f;

        link1.connectedBody = attachedBody.GetComponent<Rigidbody>();
        link1.linearLimitSpring = springJoint;
        Vector3 anchorLoc = transform.InverseTransformPoint(connectionPoint);
        link1.anchor = anchorLoc;
        link1.xMotion = ConfigurableJointMotion.Limited;
        link1.yMotion = ConfigurableJointMotion.Limited;
        link1.zMotion = ConfigurableJointMotion.Limited;
        link1.angularXMotion = ConfigurableJointMotion.Free;
        link1.angularYMotion = ConfigurableJointMotion.Free;
        link1.angularZMotion = ConfigurableJointMotion.Free;
        link1.linearLimit = springJointLimit;
        link1.xDrive = springJointDrive;
        link1.yDrive = springJointDrive;
        link1.zDrive = springJointDrive;
        return link1;
    }

    void OnCollisionEnter(Collision collision) {
        if (collision.gameObject.tag == "panel") {
            Physics.IgnoreCollision(collision.gameObject.GetComponent<Collider>(), GetComponent<Collider>(), true);
        }
    }
}
