﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingSystem : MonoBehaviour {
    GameObject hitObj;
    Ray mouseRay;
    RaycastHit hitInfo;

    public List<GameObject> startingNodes = new List<GameObject>();

    List<GameObject> sideplat1 = new List<GameObject>();
    List<GameObject> sideplat2 = new List<GameObject>();
    List<GameObject> sideplat3 = new List<GameObject>();
    List<GameObject> sideplat4 = new List<GameObject>();

    public GameObject nodePrefab;
    public List<GameObject> ghostNodes = new List<GameObject>();

    public Material panelMat;

    public float mouseMovement = 0;
    Vector3 mousePos = Vector3.zero;
    Vector3 mousePreviousPos = Vector3.zero;

    private void OnGUI() {
        mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition);
        mousePos = Input.mousePosition;
        mouseMovement = Mathf.Abs((mousePos - mousePreviousPos).magnitude);
        mousePreviousPos = mousePos;
    }

    private void Start() {
        Construct(startingNodes);
    }

    private void Update() {
        if (Physics.Raycast(mouseRay, out hitInfo) && !Input.GetMouseButton(0)) {
            if (hitInfo.collider.gameObject.tag == "Panel") {
                hitObj = hitInfo.collider.gameObject;
            }
        }
        if (Input.GetMouseButton(0)) {
            if (hitObj) {
                Extrude(hitObj);
            }
        } else if (Input.GetMouseButtonUp(0)) {
            Construct(ghostNodes);
            Construct(sideplat1);
            Construct(sideplat2);
            Construct(sideplat3);
            Construct(sideplat4);
            sideplat1.Clear();
            sideplat2.Clear();
            sideplat3.Clear();
            sideplat4.Clear();
            hitObj = null;
            ghostNodes.Clear();
        } else {

        }
    }

    void Extrude(GameObject extrudePanel) {
        PanelScript panelScript = extrudePanel.GetComponent<PanelScript>();
        //for the 4 nodes of the selected panel
        for (int i = 0; i < panelScript.nodes.Count; i++) {
            //If ghost nodes haven't been assigned yet
            if (ghostNodes.Count < panelScript.nodes.Count) {
                ghostNodes.Insert(i, Instantiate(nodePrefab, panelScript.nodes[i].transform.position, panelScript.nodes[i].transform.rotation));
            } else {

                float mouseDis = 1;

                Vector3 normal = extrudePanel.GetComponent<MeshFilter>().mesh.normals[0];
                ghostNodes[i].transform.position = panelScript.nodes[i].transform.position + (normal * mouseDis);
            }
        }

        //Panel 1
        if (!sideplat1.Contains(panelScript.nodes[0])) {
            sideplat1.Add(panelScript.nodes[0]);
            sideplat1.Add(panelScript.nodes[1]);
            sideplat1.Add(ghostNodes[1]);
            sideplat1.Add(ghostNodes[0]);
        }
        //Panel 2
        if (!sideplat2.Contains(panelScript.nodes[1])) {
            sideplat2.Add(panelScript.nodes[1]);
            sideplat2.Add(panelScript.nodes[2]);
            sideplat2.Add(ghostNodes[2]);
            sideplat2.Add(ghostNodes[1]);
        }
        //Panel 1
        if (!sideplat3.Contains(panelScript.nodes[2])) {
            sideplat3.Add(panelScript.nodes[2]);
            sideplat3.Add(panelScript.nodes[3]);
            sideplat3.Add(ghostNodes[3]);
            sideplat3.Add(ghostNodes[2]);
        }
        //Panel 2
        if (!sideplat4.Contains(panelScript.nodes[3])) {
            sideplat4.Add(panelScript.nodes[3]);
            sideplat4.Add(panelScript.nodes[0]);
            sideplat4.Add(ghostNodes[0]);
            sideplat4.Add(ghostNodes[3]);
        }
    }

    void Construct(List<GameObject> assignedNodes) {
        //get the node connectors to each node
        List<GameObject> nodeConnectors = new List<GameObject>() {
            assignedNodes[0].GetComponent<NodeScript>().nodeConnector,
            assignedNodes[1].GetComponent<NodeScript>().nodeConnector,
            assignedNodes[2].GetComponent<NodeScript>().nodeConnector,
            assignedNodes[3].GetComponent<NodeScript>().nodeConnector,
        };
        //get locations of the assigned nodes
        Vector3[] vertices = new Vector3[] {
            nodeConnectors[0].transform.position,
            nodeConnectors[1].transform.position,
            nodeConnectors[2].transform.position,
            nodeConnectors[3].transform.position,
        };
        GameObject panel = PanelBuilder.CreatePlane(vertices, true, panelMat);
        panel.GetComponent<PanelScript>().AssignNodes(nodeConnectors);
    }
}
